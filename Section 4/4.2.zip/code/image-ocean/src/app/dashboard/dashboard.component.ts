import { Component, OnInit } from '@angular/core';
import { Image } from '../entities/image';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  images : Image[] = []

  constructor(private http : HttpClient) {

  }

  ngOnInit() {
    this.http.get('http://localhost:3000/images').subscribe(data => {
      this.images = data['images'].map(imageData => new Image(imageData));
    });
  }

}
