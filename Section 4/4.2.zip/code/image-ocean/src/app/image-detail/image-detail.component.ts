import { Component, OnInit } from '@angular/core';
import { Image } from '../entities/image';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-image-detail',
  templateUrl: './image-detail.component.html',
  styleUrls: ['./image-detail.component.scss']
})
export class ImageDetailComponent implements OnInit {
  image : Image

  constructor(
    private route : ActivatedRoute,
    private router : Router,
    private http : HttpClient
  ) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.http.get(`http://localhost:3000/images/${+params.id}`).subscribe(data => {
        this.image = new Image(data['image']);
      });
    });
  }

}
