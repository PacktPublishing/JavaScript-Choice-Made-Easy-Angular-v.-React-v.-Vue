import { Component, OnInit } from '@angular/core';
import { Image } from '../entities/image';

export const IMAGES_MOCK = [
  new Image({
    id: 0,
    fileName: 'red_fish.jpg',
    title: 'Red fish'
  }),
  new Image({
    id: 1,
    fileName: 'shark.jpg',
    title: 'Shark'
  })
];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  images : Image[] = []

  constructor() {
    this.images = IMAGES_MOCK;
  }

  ngOnInit() {
  }

}
