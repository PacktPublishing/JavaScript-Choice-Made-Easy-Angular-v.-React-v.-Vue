const GALLERY_IMAGES_PATH = 'assets/images/gallery';

export class Image {
  id : number

  fileName : string

  title : string

  liked : Boolean

  like() : void {
    this.liked = true;
  }

  get imagePath() : string {
    return `${GALLERY_IMAGES_PATH}/${this.fileName}`
  }

  constructor(fields?) {
    if (fields) {
      Object.assign(this, fields);
    }
  }
}
