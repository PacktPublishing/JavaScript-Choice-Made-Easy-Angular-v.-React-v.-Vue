const outlet = document.getElementsByClassName('outlet')[0];

const PRODUCTS = [
    {
        name: 'Shirt',
        price: '$60',
        available: true
    },
    {
        name: 'Shoes',
        price: '$120',
        available: true
    },
    {
        name: 'Trousers',
        price: '$75',
        available: false
    }
];

class ProductComponent {
    constructor($element) {
        this.$element = $element;

        this.product = PRODUCTS.find(p => p.name === $element.attr('data-product-name'));

        this.render();
    }

    render() {
        if (!this.template) {
            this.template = Handlebars.compile($('#product-component-template').html());  
        }

        this.$element.empty();

        this.$element.append(
            this.template({
                product: this.product
            })
        );

        const $buyButton = this.$element.children('footer').children('button');

        $buyButton.on('click', () => this.buy());
    }

    buy() {
        this.product.available = false;

        this.render();
    }
}

function setupComponents() {
    $('product-component').each(
        (index, element) => new ProductComponent($(element))
    );
}

function renderList(products) {
    const compiledTemplate = Handlebars.compile($('#list-template').html());

    outlet.innerHTML = compiledTemplate({ products });

    setupComponents();
}

function renderDetails(product) {
    const compiledTemplate = Handlebars.compile($('#details-template').html());
    
    outlet.innerHTML = compiledTemplate({ product });
}

function renderLandingPage() {
    const compiledTemplate = Handlebars.compile($('#landing-page-template').html());

    outlet.innerHTML = compiledTemplate();
}

function renderPageNotFound() {
    const compiledTemplate = Handlebars.compile($('#not-found-template').html());

    outlet.innerHTML = compiledTemplate();
}

const router = new Router.default();

const HANDLERS = {
    showLandingPage: {
        setup() {
            renderLandingPage();
        }
    },

    showList: {
        model: () => PRODUCTS,

        setup(model) {
            renderList(model);
        }
    },

    showDetails: {
        model: (params) => PRODUCTS.find(p => p.name === params.name),

        setup(model) {
            renderDetails(model);
        }
    },

    notFound: {
        setup() {
            renderPageNotFound();
        }
    }
};

router.getHandler = name => HANDLERS[name];

router.updateURL = url => window.location.hash = url;

router.map(match => {
    match('*notfound').to('notFound');
    match('/').to('showLandingPage');
    match('/list').to('showList');
    match('/details/:name').to('showDetails');    
});

const startRouting = () => router.handleURL(window.location.hash.replace('#', ''));

$(window).on('hashchange', startRouting);

startRouting();