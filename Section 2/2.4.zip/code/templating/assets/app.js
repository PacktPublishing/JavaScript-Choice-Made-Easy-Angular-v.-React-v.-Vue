const outlet = document.getElementsByClassName('outlet')[0];

function renderList() {
    const compiledTemplate = Handlebars.compile($('#list-template').html());

    outlet.innerHTML = compiledTemplate();
}

function renderDetails(name) {
    const compiledTemplate = Handlebars.compile($('#details-template').html());
    
    outlet.innerHTML = compiledTemplate({
        name: name.toUpperCase()
    });
}

function renderLandingPage() {
    const compiledTemplate = Handlebars.compile($('#landing-page-template').html());

    outlet.innerHTML = compiledTemplate();
}

function renderPageNotFound() {
    const compiledTemplate = Handlebars.compile($('#not-found-template').html());

    outlet.innerHTML = compiledTemplate();
}

const router = new Router.default();

const HANDLERS = {
    showLandingPage: {
        setup() {
            renderLandingPage();
        }
    },

    showList: {
        setup() {
            renderList();
        }
    },

    showDetails: {
        model: params => params,

        setup({ name }) {
            renderDetails(name);
        }
    },

    notFound: {
        setup() {
            renderPageNotFound();
        }
    }
};

router.getHandler = name => HANDLERS[name];

router.updateURL = url => window.location.hash = url;

router.map(match => {
    match('*notfound').to('notFound');
    match('/').to('showLandingPage');
    match('/list').to('showList');
    match('/details/:name').to('showDetails');    
});

const startRouting = () => router.handleURL(window.location.hash.replace('#', ''));

$(window).on('hashchange', startRouting);

startRouting();