const outlet = document.getElementsByClassName('outlet')[0];

function showList() {
    outlet.innerHTML =
        `
            <h2>List</h2>
            <ul>
                <li><a href="#details">Product</a></li>
            </ul>
        `;
}

function showDetails() {
    outlet.innerHTML =
        `
            <h2>Product details</h2>
            <br/>
            Product name: <b>Shirt</b>
        `;
}

function showLandingPage() {
    outlet.innerHTML = '<h2>Landing page</h2>';
}

function pageNotFound() {
    outlet.innerHTML =
        `
            <b>We could not find page you've requested.</b>
        `;
}

function router(hash) {
    switch (hash) {
        case '#list':
            showList();
            break;
        case '#details':
            showDetails();
            break;
        case '':
            showLandingPage();
            break;
        default:
            pageNotFound();
            break;
    }
}

$(() => {
    router(window.location.hash);
});

$(window).on('hashchange', () => {
    router(window.location.hash);
});
