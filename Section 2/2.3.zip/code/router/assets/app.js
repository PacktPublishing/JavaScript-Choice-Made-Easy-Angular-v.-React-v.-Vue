const outlet = document.getElementsByClassName('outlet')[0];

function renderList() {
    outlet.innerHTML =
        `
            <h2>List</h2>
            <ul>
                <li><a href="#details/shirt">Shirt</a></li>
                <li><a href="#details/shoes">Shoes</a></li>
            </ul>
        `;
}

function renderDetails(name) {
    outlet.innerHTML =
        `
            <h2>Product details</h2>
            <br/>
            Product name: <b>${name.toUpperCase()}</b>
        `;
}

function renderLandingPage() {
    outlet.innerHTML = '<h2>Landing page</h2>';
}

function renderPageNotFound() {
    outlet.innerHTML =
        `
            <b>We could not find page you've requested.</b>
        `;
}

const router = new Router.default();

const HANDLERS = {
    showLandingPage: {
        setup() {
            renderLandingPage();
        }
    },

    showList: {
        setup() {
            renderList();
        }
    },

    showDetails: {
        model(params) {
            return params;
        },

        setup({ name }) {
            renderDetails(name);
        }
    },

    notFound: {
        setup() {
            renderPageNotFound();
        }
    }
};

router.getHandler = name => HANDLERS[name];

router.updateURL = url => window.location.hash = url;

router.map(match => {
    match('*notfound').to('notFound');
    match('/').to('showLandingPage');
    match('/list').to('showList');
    match('/details/:name').to('showDetails');    
});

const startRouting = () => router.handleURL(window.location.hash.replace('#', ''));

$(window).on('hashchange', startRouting);

startRouting();