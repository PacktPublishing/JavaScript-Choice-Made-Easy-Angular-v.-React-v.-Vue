function appendToDiv(div, amount, elements) {
    let i = 0;

    const fragment = document.createDocumentFragment();

    for (let i = 1; i < amount; i++) {
        const newElement = document.createElement('div');
        newElement.innerHTML = elements[i];
        
        fragment.appendChild(newElement);
    }

    div.appendChild(fragment);
}

function getUSACities() {
    return new Promise(resolve => {
        $.get(
            'assets/usa-cities.json',
            response => resolve(response['United States'])
        );
    });
}

function start() {
    getUSACities().then(cities => {
        const AMOUNT_OF_ELEMENTS = 1000;

        const startTime = performance.now();

        appendToDiv(document.body, AMOUNT_OF_ELEMENTS, cities);

        const endTime = performance.now();

        document
        .getElementById('time')
        .innerHTML = `${Math.round(endTime - startTime)} milliseconds`;
    });
}
