import React, { Component } from 'react';
import './styles.css';
import Cart from '../Cart/component';
import Dashboard from '../Dashboard/component';
import CategoryDetails from '../CategoryDetails/component';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
            <div className="App-header">
                <div className="App-title animated zoomIn">
                    <Link to="/"><h2>CLOTHES ON FIRE</h2></Link>
                </div>
                <Cart/>
            </div>
            <Route exact path="/" component={Dashboard} />
            <Route path="/category/:id" component={CategoryDetails} />
        </div>
      </Router>
    );
  }
}

export default App;
