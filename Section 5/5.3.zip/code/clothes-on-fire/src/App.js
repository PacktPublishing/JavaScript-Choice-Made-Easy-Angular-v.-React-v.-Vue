import React, { Component } from 'react';
import './App.css';
import MenImage from './images/categories/men.jpg';
import LadiesImage from './images/categories/ladies.jpg';

const CATEGORIES = [
    {
        name: "Men's Fashion",
        image: MenImage,
        imageStyle: {
            marginTop: '-250px'
        },
        titleStyle: {
            right: '17%'
        }
    },
    {
        name: 'Ladies Fashion',
        image: LadiesImage,
        imageStyle: {
            marginTop: '-240px'
        },
        titleStyle: {
            left: '17%'
        }
    }
];

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
            <div className="App-title animated zoomIn">
                <h2>CLOTHES ON FIRE</h2>
            </div>
            <div className="App-cart">🛒 CART</div>
        </div>
        <div className="App-categories">
            {CATEGORIES.map((category, index) => {
                return (
                <div className="App-category" key={index}>
                    <img src={category.image} className="App-category-front-image" style={category.imageStyle} alt="" />
                    <div className="App-category-title" style={category.titleStyle}>{category.name}</div>
                </div>
                );
            })}
        </div>
      </div>
    );
  }
}

export default App;
