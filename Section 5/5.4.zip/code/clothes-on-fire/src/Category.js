import React from 'react';

function Category({ category }) {
    return (
        <div className="App-category">
            <img src={category.image} className="App-category-front-image" style={category.imageStyle} alt="" />
            <div className="App-category-title" style={category.titleStyle}>{category.name}</div>
        </div>
    );
}

export default Category;