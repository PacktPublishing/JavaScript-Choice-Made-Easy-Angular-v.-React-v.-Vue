import React, { Component } from 'react';
import './App.css';
import MenImage from './images/categories/men.jpg';
import LadiesImage from './images/categories/ladies.jpg';
import Category from './Category';
import Cart from './Cart';

const CATEGORIES = [
    {
        name: "Men's Fashion",
        image: MenImage,
        imageStyle: {
            marginTop: '-250px'
        },
        titleStyle: {
            right: '17%'
        }
    },
    {
        name: 'Ladies Fashion',
        image: LadiesImage,
        imageStyle: {
            marginTop: '-240px'
        },
        titleStyle: {
            left: '17%'
        }
    }
];

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
            <div className="App-title animated zoomIn">
                <h2>CLOTHES ON FIRE</h2>
            </div>
            <Cart/>
        </div>
        <div className="App-categories">
            {CATEGORIES.map((category, index) =>
                <Category category={category} key={index} />
            )}
        </div>
      </div>
    );
  }
}

export default App;
