import { combineReducers } from 'redux';
import { TOGGLE_CART_VISIBILITY } from './actions';

const INITIAL_CART_STATE = {
    isExpanded: false
};

function cart(state = INITIAL_CART_STATE, action) {
    switch (action.type) {
        case TOGGLE_CART_VISIBILITY:
            return {
                isExpanded: !state.isExpanded
            };
        default:
            return state;
    }
}

const appReducer = combineReducers({
    cart
});

export default appReducer;