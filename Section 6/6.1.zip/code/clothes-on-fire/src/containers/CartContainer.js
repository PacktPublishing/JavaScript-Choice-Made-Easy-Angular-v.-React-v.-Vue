import { connect } from 'react-redux';
import { toggleCartVisibility } from '../actions';
import Cart from '../components/Cart/component';

const mapStateToProps = state => {
    return {
        isExpanded: state.cart.isExpanded
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onCartButtonClick: () => {
            dispatch(toggleCartVisibility())
        }
    };
};

const CartContainer = connect(mapStateToProps, mapDispatchToProps)(Cart);

export default CartContainer;