/*
 * action types
 */

export const TOGGLE_CART_VISIBILITY = 'TOGGLE_CART_VISIBILITY';

/*
 * action creators
 */

export function toggleCartVisibility() {
  return { type: TOGGLE_CART_VISIBILITY };
}
