import React from 'react';
import DisplayProduct from '../DisplayProduct/component';
import './styles.css';
import CATEGORIES from '../../data/categories';

function CategoryDetails(props) {
    const categoryId = props.match.params.id;
    const category = CATEGORIES.find(category => category.id === categoryId);

    return (
        <div className="CategoryDetails">
            {category.products.map((product, index) => (
                <DisplayProduct product={product} key={index} />
            ))}
        </div>
    );
}

export default CategoryDetails;