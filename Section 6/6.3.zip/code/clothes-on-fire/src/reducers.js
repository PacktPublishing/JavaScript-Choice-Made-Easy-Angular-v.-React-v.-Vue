import { combineReducers } from 'redux';
import { TOGGLE_CART_VISIBILITY, ADD_PRODUCT_TO_CART } from './actions';
import { getProductById } from './data/products';

const INITIAL_CART_STATE = {
    isExpanded: false,
    products: []
};

function cart(state = INITIAL_CART_STATE, action) {
    switch (action.type) {
        case TOGGLE_CART_VISIBILITY:
            return {
                isExpanded: !state.isExpanded,
                products: state.products
            };
        case ADD_PRODUCT_TO_CART:
            return {
                isExpanded: state.isExpanded,
                products: [
                    ...state.products,
                    getProductById(action.id)
                ]
            };
        default:
            return state;
    }
}

const appReducer = combineReducers({
    cart
});

export default appReducer;