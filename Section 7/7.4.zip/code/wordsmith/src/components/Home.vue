<template>
  <div class="home">
    <ul class="post-list">
      <article-preview v-for="post in posts" :key="post.id" :post="post" @onTitleClicked="title => currentlySelectedPostTitle = title" />
    </ul>

    Currently selected blog post: <b>{{currentlySelectedPostTitle}}</b>
  </div>
</template>

<script>
import ArticlePreview from './ArticlePreview'

export default {
  name: 'home',

  data () {
    return {
      posts: [
        {
          id: 0,
          image: 'static/bearded-man-200.jpeg',
          title: 'FIRST BLOG POST',
          excerpt: `Blogging about programming gets more and more popular. Is it hard to begin writing? See for yourself.
          For the past year I have observed blogging trends. I’ll share with you my research. You can draw your own conclusions.
          Be careful! This is powerful knowledge. Please use it carefully and remember about this article when you’ll get to the top.
          Tips to become fulfilled blogger...`,
          date: '23 May 2017'
        },
        {
          id: 1,
          image: 'static/rapper-200.png',
          title: 'SECOND BLOG POST',
          excerpt: `Hello, I’m humble developer who works with a lot of JavaScript frameworks, libraries, modules, addons, plugins, browsers, preprocessors, processors, postprocessors, plugins for processors (Autoprefixer), plugins for browsers (Ember inspector), plugins for libraries (jQuery), addons for frameworks.
          Isn’t it a lot of tools that we need to work with on daily basis? How big is your package.json file? Do you know what...`,
          date: '06 May 2017'
        }
      ],
      currentlySelectedPostTitle: ''
    }
  },

  components: {
    'article-preview': ArticlePreview
  }
}
</script>

<style lang="scss" scoped>
ul {
  list-style-type: none;
  padding: 0;
  overflow: hidden;
  margin-bottom: 15px;
}
</style>
