<template>
  <div class="home">
    <ul class="post-list">
      <li v-for="post in posts" :key="post.id">
        <img :src="post.image" class="post-thumbnail">

        <h2>
          <a class="post-link" href="#">{{post.title}}</a>
        </h2>
        <div class="post-excerpt">{{post.excerpt}}</div>

        <div class="post-footer">
            <div class="post-date">{{post.date}}</div>
        </div>
      </li>
  </ul>
  </div>
</template>

<script>
export default {
  name: 'home',

  data () {
    return {
      posts: [
        {
          id: 0,
          image: 'static/bearded-man-200.jpeg',
          title: 'FIRST BLOG POST',
          excerpt: `Blogging about programming gets more and more popular. Is it hard to begin writing? See for yourself.
          For the past year I have observed blogging trends. I’ll share with you my research. You can draw your own conclusions.
          Be careful! This is powerful knowledge. Please use it carefully and remember about this article when you’ll get to the top.
          Tips to become fulfilled blogger...`,
          date: '23 May 2017'
        },
        {
          id: 1,
          image: 'static/rapper-200.png',
          title: 'SECOND BLOG POST',
          excerpt: `Hello, I’m humble developer who works with a lot of JavaScript frameworks, libraries, modules, addons, plugins, browsers, preprocessors, processors, postprocessors, plugins for processors (Autoprefixer), plugins for browsers (Ember inspector), plugins for libraries (jQuery), addons for frameworks.
          Isn’t it a lot of tools that we need to work with on daily basis? How big is your package.json file? Do you know what...`,
          date: '06 May 2017'
        }
      ]
    }
  }
}
</script>

<style lang="scss" scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
  overflow: hidden;
  margin-bottom: 15px;
}

.post-list {
  li {
    margin-bottom: 0;

    &:not(:first-child) {
      margin-top: 40px;
    }
  }
}

a.post-link {
  text-transform: uppercase;
  color: #000;
}

.post-link {
  display: block;
  font-size: 24px;
}

.post-excerpt {
  font-size: 14px;
  font-style: italic;
  opacity: 0.6;
  -webkit-margin-before: 1em;
  -webkit-margin-after: 1em;
  -webkit-margin-start: 0px;
  -webkit-margin-end: 0px;
  color: inherit;
  display: block;
  pointer-events: none;
}

.post-footer {
  display: inline-block;
  width: 100%;
  position: relative;
}

.post-date {
  width: 188px;
  text-align: center;
  font-size: 12px;
  background: #000;
  display: inline-block;
  color: white;
  padding: 6px;
  text-transform: uppercase;
}

.post-thumbnail {
  filter: grayscale(100%);
  margin-top: 10px;
  width: 200px;
  height: 200px;
  padding-right: 20px;
  padding-bottom: 10px;
  max-width: 100%;
  vertical-align: middle;
  float: left;

  &:hover {
    filter: none;
  }
}
</style>
