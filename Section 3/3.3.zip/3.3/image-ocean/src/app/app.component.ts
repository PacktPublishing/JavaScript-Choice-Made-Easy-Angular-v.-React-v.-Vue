import { Component, OnInit } from '@angular/core';
import { Image } from './entities/image';

declare const particlesJS: any;

const PARTICLES_CONFIG_PATH = 'assets/config/particlesjs-config.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  image : Image = null

  constructor() {
    this.image = new Image({
      fileName: 'red_fish.jpg',
      title: 'Red fish'
    });
  }

  ngOnInit(): void {
    particlesJS.load('particles-js', PARTICLES_CONFIG_PATH, null);
  }
}
