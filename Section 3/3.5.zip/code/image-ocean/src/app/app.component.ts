import { Component, OnInit } from '@angular/core';
import { Image } from './entities/image';

declare const particlesJS: any;

const PARTICLES_CONFIG_PATH = 'assets/config/particlesjs-config.json';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  images : Image[] = []

  constructor() {
    this.images = [
      new Image({
        fileName: 'red_fish.jpg',
        title: 'Red fish'
      }),
      new Image({
        fileName: 'shark.jpg',
        title: 'Shark'
      })
    ];
  }

  ngOnInit(): void {
    particlesJS.load('particles-js', PARTICLES_CONFIG_PATH, null);
  }
}
